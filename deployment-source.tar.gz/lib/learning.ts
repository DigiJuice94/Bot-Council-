import type { AgentPerformance, ResearchAgentId, ResearchAgentWeights } from "./types";

/**
 * Trading-policy era for learning. Bump this whenever the entry/exit policy
 * changes materially (risk gates, sizing, slippage handling): performance rows
 * and memory lessons from older eras are excluded from weight blending so the
 * system re-learns the new game instead of dragging the old one along.
 *
 * v3 = post risk-fix era (entry gates, kill switches, 1% unverified caps,
 * honest exits). Earlier rows predate the current policy and are ignored.
 */
export const LEARNING_POLICY_VERSION = 3;

/** Observations decay with this half-life so recent trades teach more than old ones. */
export const LEARNING_OBS_HALF_LIFE_DAYS = 14;

/** Shrinkage strength: how many pseudo-observations of the prior a segment blends against. */
export const LEARNING_SHRINKAGE_K = 12;

export const DEFAULT_AGENT_WEIGHTS: ResearchAgentWeights = {
  launch: 0.12,
  social: 0.10,
  wallet: 0.18,
  quant: 0.23,
  contract: 0.27,
  bear: 0.10,
};

const researchIds: ResearchAgentId[] = ["launch", "social", "wallet", "quant", "contract", "bear"];

export function normalizeResearchWeights(input: Partial<ResearchAgentWeights>): ResearchAgentWeights {
  const raw = researchIds.map((id) => Math.max(0.04, Number(input[id] ?? DEFAULT_AGENT_WEIGHTS[id])));
  const total = raw.reduce((sum, value) => sum + value, 0) || 1;
  return Object.fromEntries(researchIds.map((id, index) => [id, raw[index] / total])) as ResearchAgentWeights;
}

export function weightsFromPerformance(records: AgentPerformance[]): ResearchAgentWeights {
  if (!records.length) return DEFAULT_AGENT_WEIGHTS;
  const map = new Map(records.map((record) => [record.agentId, record]));
  const proposed: Partial<ResearchAgentWeights> = {};
  for (const id of researchIds) {
    const record = map.get(id);
    // Records arrive pre-shrunk toward defaults, so thin data yields near-zero
    // lifts automatically — no hard observation gate needed.
    if (!record || !(record.observations > 0)) {
      proposed[id] = DEFAULT_AGENT_WEIGHTS[id];
      continue;
    }
    const directionalLift = Math.max(-0.25, Math.min(0.25, (record.directionalAccuracyPct - 50) / 100));
    const reasoningLift = Math.max(-0.15, Math.min(0.15, (record.reasoningAccuracyPct - 50) / 125));
    const edgeLift = Math.max(-0.18, Math.min(0.18, record.avgEdgePct / 50));
    // Dollar edge: learn what actually makes money, not just what's directionally right.
    const pnlLift = Math.max(-0.15, Math.min(0.15, record.avgPnlUsd / 50));
    proposed[id] = DEFAULT_AGENT_WEIGHTS[id] * (1 + directionalLift + reasoningLift + edgeLift + pnlLift);
  }
  return normalizeResearchWeights(proposed);
}

/**
 * Fraction of an observation's weight surviving from updatedAt to nowMs under
 * exponential half-life decay. Missing/invalid timestamps (pre-versioning rows)
 * return 0 so stale eras phase out naturally.
 */
export function decayFactor(updatedAt: string | undefined, nowMs = Date.now()): number {
  if (!updatedAt) return 0;
  const updatedMs = Date.parse(updatedAt);
  if (!Number.isFinite(updatedMs)) return 0;
  const ageDays = Math.max(0, (nowMs - updatedMs) / 86_400_000);
  return Math.pow(0.5, ageDays / LEARNING_OBS_HALF_LIFE_DAYS);
}

/**
 * Effective observation count after exponential time decay. Rows without a
 * timestamp (pre-versioning) decay to ~0 so stale eras phase out naturally.
 */
export function decayedObservations(observations: number, updatedAt: string | undefined, nowMs = Date.now()): number {
  if (!observations || observations <= 0) return 0;
  return observations * decayFactor(updatedAt, nowMs);
}

/** Shrink a segment estimate toward a prior: n/(n+k) segment + k/(n+k) prior. */
export function shrinkToward(value: number, prior: number, n: number, k = LEARNING_SHRINKAGE_K): number {
  if (!(n > 0)) return prior;
  return (n * value + k * prior) / (n + k);
}

export function scoreAgentOutcome(score: number, realizedReturnPct: number) {
  const expectedUp = score >= 58;
  const realizedUp = realizedReturnPct > 0;
  return { correct: expectedUp === realizedUp, edgePct: realizedReturnPct * ((score - 50) / 50) };
}
