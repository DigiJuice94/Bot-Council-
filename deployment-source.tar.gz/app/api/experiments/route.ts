import { NextRequest, NextResponse } from "next/server";
import { buildCabinetExport, type CabinetKind } from "@/lib/cabinet-export";
export const dynamic="force-dynamic";
export async function GET(request:NextRequest){const kind=undefined as unknown as CabinetKind;if(!["main","rug","proof"].includes(kind))return NextResponse.json({error:"Unknown cabinet"},{status:404});const data=await buildCabinetExport(kind);if(request.nextUrl.searchParams.get("download")==="1")return new NextResponse(JSON.stringify(data,null,2),{headers:{"Content-Type":"application/json","Content-Disposition":`attachment; filename="bot-war-room-${kind}-cabinet-${new Date().toISOString().slice(0,10)}.json"`,"Cache-Control":"no-store"}});return NextResponse.json(data,{headers:{"Cache-Control":"no-store"}})}
